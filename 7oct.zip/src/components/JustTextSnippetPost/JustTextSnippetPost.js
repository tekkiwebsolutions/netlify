import React from "react";
import './JustTextSnippetPost.css';

function JustTextSnippetPost(){

    return(
        <div className='just_txt'>
                <h2>Lorem Ipsum is simply dummy</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy </p>
                <a href='#'>Read More</a>
            </div>
    )
}
export default JustTextSnippetPost;